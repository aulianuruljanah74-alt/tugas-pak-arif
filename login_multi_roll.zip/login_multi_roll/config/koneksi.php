<?php

$host = "localhost";
$user = "root";    // Default Laragon/XAMPP adalah root
$password = "";    // Default Laragon/XAMPP adalah kosong
$database = "db_login";

//membuat koneksi
$con = mysqli_connect($host, $user, $password, $database);

//mengecek koneksi
if (!$con) {
    die("koneksi database gagal:". mysqli_connect_error());
}
//hapus atau comment baris echo di bawah ini jika project sudah berjalan normal
//echo "koneksi database berhasil";
?>