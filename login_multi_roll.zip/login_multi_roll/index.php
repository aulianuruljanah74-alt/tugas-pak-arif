<?php
session_start();

// Jika pengguna belum login
if (!isset($_SESSION['role'])) {
    header("Location: auth/login.php");
    exit;
}

// Mengarahkan sesuai role
if ($_SESSION['role'] == 'admin') {
    header("Location: admin/dashboard.php");
    exit;
} elseif ($_SESSION['role'] == 'guru') {
    header("Location: guru/dashboard.php");
    exit;
} elseif ($_SESSION['role'] == 'siswa') {
    header("Location: siswa/dashboard.php");
    exit;
} else {
    // Jika role tidak sesuai
    session_unset();
    session_destroy();
    header("Location: auth/login.php");
    exit;
}
?>