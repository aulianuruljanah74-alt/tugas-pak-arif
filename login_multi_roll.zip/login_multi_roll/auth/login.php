<?php
session_start();
require_once '../config/koneksi.php';

if (isset($_POST['login'])) {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    // Mencari username menggunakan prepared statement
    $stmt = mysqli_prepare(
        $con,
        "SELECT * FROM users WHERE username = ?"
    );

    mysqli_stmt_bind_param($stmt, "s", $username);
    mysqli_stmt_execute($stmt);

    $query = mysqli_stmt_get_result($stmt);

    if (mysqli_num_rows($query) === 1) {
        $row = mysqli_fetch_assoc($query);

        // Memeriksa password
        if (password_verify($password, $row['password'])) {
            $_SESSION['id'] = $row['id'];
            $_SESSION['nama'] = $row['nama'];
            $_SESSION['username'] = $row['username'];
            $_SESSION['role'] = $row['role'];

            // Mengarahkan sesuai role pengguna
            if ($row['role'] == 'admin') {
                header("Location: ../admin/dashboard.php");
            } elseif ($row['role'] == 'guru') {
                header("Location: ../guru/dashboard.php");
            } else {
                header("Location: ../siswa/dashboard.php");
            }
            exit;
        } else {
            $error = "Password salah!";
        }
    } else {
        $error = "Username tidak terdaftar!";
    }

    mysqli_stmt_close($stmt);
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Sistem Multi Role</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>
<style>
    
/* Pengaturan dasar halaman */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: Arial, Helvetica, sans-serif;
    background: linear-gradient(135deg, #dbeafe, #eff6ff, #bfdbfe);
    min-height: 100vh;
    color: #1e293b;
}

/* Posisi form di tengah halaman */
.login-container {
    min-height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 20px;
}

/* Kotak login */
.login-card {
    width: 100%;
    max-width: 420px;
    background-color: #ffffff;
    padding: 35px;
    border-radius: 18px;
    box-shadow: 0 12px 35px rgba(30, 64, 175, 0.15);
    border: 1px solid #e2e8f0;
}

/* Bagian judul */
.login-header {
    text-align: center;
    margin-bottom: 28px;
}

.login-icon {
    width: 65px;
    height: 65px;
    margin: 0 auto 15px;
    display: flex;
    align-items: center;
    justify-content: center;
    background-color: #dbeafe;
    border-radius: 50%;
    font-size: 30px;
}

.login-header h1 {
    font-size: 26px;
    color: #1d4ed8;
    margin-bottom: 10px;
}

.login-header p {
    font-size: 14px;
    color: #64748b;
    line-height: 1.5;
}

/* Form input */
.form-group {
    margin-bottom: 20px;
}

.form-group label {
    display: block;
    font-size: 14px;
    font-weight: bold;
    margin-bottom: 8px;
    color: #334155;
}

.form-group input {
    width: 100%;
    padding: 13px 14px;
    border: 1px solid #cbd5e1;
    border-radius: 9px;
    outline: none;
    font-size: 14px;
    transition: 0.2s;
}

.form-group input:focus {
    border-color: #2563eb;
    box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.12);
}

/* Tombol login */
.btn-login {
    width: 100%;
    padding: 13px;
    border: none;
    border-radius: 9px;
    background-color: #2563eb;
    color: white;
    font-size: 15px;
    font-weight: bold;
    cursor: pointer;
    transition: 0.2s;
}

.btn-login:hover {
    background-color: #1d4ed8;
    transform: translateY(-1px);
}

/* Pesan error */
.error-message {
    background-color: #fee2e2;
    color: #b91c1c;
    border: 1px solid #fecaca;
    padding: 12px;
    border-radius: 8px;
    margin-bottom: 20px;
    font-size: 14px;
}

/* Link daftar */
.register-link {
    text-align: center;
    margin-top: 22px;
    font-size: 14px;
    color: #64748b;
}

.register-link a {
    color: #2563eb;
    font-weight: bold;
    text-decoration: none;
}

.register-link a:hover {
    text-decoration: underline;
}

/* Bagian bawah form */
.login-footer {
    text-align: center;
    margin-top: 25px;
    padding-top: 18px;
    border-top: 1px solid #e2e8f0;
    color: #94a3b8;
    font-size: 12px;
}

/* Tampilan HP */
@media (max-width: 480px) {
    .login-card {
        padding: 25px 20px;
    }

    .login-header h1 {
        font-size: 23px;
    }
}
</style>

    <div class="login-container">
        <div class="login-card">

            <div class="login-header">
                <h1>Selamat Datang</h1>
                <p>Silakan login untuk melanjutkan</p>
            </div>

            <?php if (isset($error)) : ?>
                <div class="error-message">
                    <?= htmlspecialchars($error) ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="">
                <div class="form-group">
                    <label for="username">Username</label>
                    <input
                        type="text"
                        id="username"
                        name="username"
                        placeholder="Masukkan username"
                        autocomplete="username"
                        required
                    >
                </div>

                <div class="form-group">
                    <label for="password">Password</label>
                    <input
                        type="password"
                        id="password"
                        name="password"
                        placeholder="Masukkan password"
                        autocomplete="current-password"
                        required
                    >
                </div>

                <button type="submit" name="login" class="btn-login">
                    Login
                </button>
            </form>

            <p class="register-link">
                Belum punya akun?
                <a href="register.php">Daftar di sini</a>
            </p>

            <div class="login-footer">
                Sistem Autentikasi Multi Role
            </div>

        </div>
    </div>

</body>
</html>